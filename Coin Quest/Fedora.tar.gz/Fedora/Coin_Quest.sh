#!/bin/sh

exec ./Coin_Quest
