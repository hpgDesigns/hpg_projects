#!/bin/bash
cd ~/
echo "Installing extra libraries........."

dnf install zlib-devel glew glew-devel glm-devel libogg-devel alure alure-devel libpng-devel Box2D-devel SDL-devel libffi-devel libX11-devel libXrandr-devel libXinerama-devel pugixml-devel dumb dumb-devel libvorbis-devel fluidsynth fluidsynth-devel gstreamer1-plugins-bad-free-fluidsynth fluidsynth-libs

echo "Extra libraries finished installed."
